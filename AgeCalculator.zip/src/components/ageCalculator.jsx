import React, { useState } from "react";
import "../components/cssFiles/AgeCalc.css";
import { Input, Button, Typography, notification } from "antd";
const { Text } = Typography;
var rootStyle = {
  backgroundColor: "#000033",
  color: "white",
  height: "100vh",
  minHeight: "100vh",
  padding: "2%",
};
const AgeCalculator = (props) => {
  const [birthDate, setBirthDate] = useState("");
  const [birthMonth, setBirthMonth] = useState("");
  const [birthYear, setBirthYear] = useState("");
  const [calculatedDay, setCalculatedDay] = useState("");
  const [calculatedMonth, setCalculatedMonth] = useState("");
  const [calculatedYear, setCalculatedYear] = useState("");
  const [showHideText, setShowHideText] = useState(false);

  const verification = () => {
    if (birthDate == "" || birthMonth == "" || birthYear == "") {
      notification.error({
        message: "Please fill the filds.",
      });
      setShowHideText(false);
    } else if (birthDate <= 0 || birthMonth <= 0 || birthYear <= 0) {
      notification.error({
        message: "Please enter the valid number.",
      });
      setShowHideText(false);
    } else {
      setShowHideText(true);
    }
  };
  const calculateAge = () => {
    verification();
    var date = new Date();
    var currentDate = date.getDate();
    var currentMonth = 1 + date.getMonth();
    var currentYear = date.getFullYear();
    var months = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    if (birthDate > currentDate) {
      currentDate = currentDate + months[currentMonth - 1];
      currentMonth = currentMonth - 1;
    }
    if (birthMonth > currentMonth) {
      currentMonth = currentMonth + 12;
      currentYear = currentYear - 1;
    }
    setCalculatedDay(currentDate - birthDate);
    setCalculatedMonth(currentMonth - birthMonth);
    setCalculatedYear(currentYear - birthYear);
    clearInputBox();
  };
  const clearInputBox = () => {
    setBirthDate("");
    setBirthMonth("");
    setBirthYear("");
  };
  return (
    <div style={rootStyle}>
      <h1>Calculate Your Age</h1>
      <div id="div">
        <h2>Your Birth Date: </h2>
        <Input
          className="input"
          type="number"
          min={1}
          max={31}
          value={birthDate}
          onChange={(event) => {
            setBirthDate(event.target.value);
          }}
          size="large"
          placeholder="Enter your birth date"
        />
        <Input
          className="input"
          type="number"
          min={1}
          max={12}
          value={birthMonth}
          size="large"
          placeholder="Enter your birth month"
          onChange={(e) => {
            setBirthMonth(e.target.value);
          }}
        />
        <Input
          className="input"
          type="number"
          min={1900}
          max={2022}
          value={birthYear}
          size="large"
          placeholder="Enter your full birth year"
          onChange={(e) => {
            setBirthYear(e.target.value);
          }}
        />

        <Button
          size="large"
          type="primary"
          shape="circle"
          onClick={calculateAge}
        >
          Go
        </Button>
      </div>
      {showHideText ? (
        <Text id="text" keyboard>
          Your Age is: {calculatedYear} Year {calculatedMonth} Months{" "}
          {calculatedDay} Days
        </Text>
      ) : null}
    </div>
  );
};

export default AgeCalculator;
