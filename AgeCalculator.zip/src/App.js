import logo from './logo.svg';
// import './App.css';
import AgeCalculator from './components/ageCalculator';

function App() {
  return (
    <div className="App">
      <AgeCalculator/>
    </div>
  );
}

export default App;
